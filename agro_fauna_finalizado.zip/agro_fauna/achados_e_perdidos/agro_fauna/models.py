from urllib import response
from django.db import models

# Create your models here.
class acha_e_perdido(models.Model):    
    id = models.AutoField(primary_key=True, default=None, blank=False, null=False) 
    CATEGORIA = models.CharField(max_length=12,default=None, blank=True, null=True) 
    STATUS_HISTORICO = models.CharField(max_length=10,default=None, blank=True, null=True) 
    NOME_ITEM = models.CharField(max_length=150, default=None, blank=True, null=True)
    DESC_ITEM = models.CharField(max_length=150, default=None, blank=True, null=True)
    CONTATO = models.CharField(max_length=150, default=None, blank=True, null=True)
    OBS = models.CharField(max_length=150, default=None, blank=True, null=True)

class categorias_itens(models.Model):
    id = models.AutoField(primary_key=True, default=None, blank=False, null=False) 
    desc = models.CharField(max_length=150, default=None, blank=True, null=True)
    
class api_bd(models.Model):
    id = models.AutoField(primary_key=True, default=None, blank=False, null=False) 
    response = models.TextField(default=None, blank=True, null=True)
    fact = models.TextField(default=None, blank=True, null=True) 
    like = models.CharField(max_length=1,default=None, blank=True, null=True) 
    