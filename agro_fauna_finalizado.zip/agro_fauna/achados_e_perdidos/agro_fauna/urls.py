
from django.urls import path


from agro_fauna import views
from agro_fauna import templates
from django.conf import settings
# from django.conf.urls.static import static
# from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [

    path('', views.home, name='home'), 

    path('home', views.home, name='home'), 

    path('create', views.create, name='create'), 

    path('update', views.update, name='update'), 

    path('api', views.api, name='api'), 
] 

handler500 = 'agro_fauna.views.error_500' 
# urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# urlpatterns += staticfiles_urlpatterns()
