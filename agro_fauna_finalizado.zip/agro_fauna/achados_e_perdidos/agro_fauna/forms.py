from django.forms import ModelForm 
from django import forms
from .models import *

class form_acha_e_perdido(ModelForm):
    class Meta:
        model = acha_e_perdido
        fields = ('__all__')

class form_api(ModelForm):
    class Meta:
        model = api_bd
        fields = ('__all__')