from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect, render
from .models import *
from .forms import *

# Create your views here.
def home(request):
    if request.method=="POST":
        response_data={}
        response_data['res_']=list(acha_e_perdido.objects.filter(CATEGORIA=request.POST['arg']).values() | acha_e_perdido.objects.filter(NOME_ITEM=request.POST['arg']).values())
        return JsonResponse(response_data)
    context={} 
    return render(request, "home.html", context)

def create(request):
    if request.method=="POST":
        r=request.POST.copy()
        r.update({'STATUS_HISTORICO':'Perdido'})
        form=form_acha_e_perdido(r)
        if form.is_valid():
            form.save()
            return redirect("update")
    data_f=categorias_itens.objects.all()
    context={'data_f':data_f} 
    return render(request, "create.html", context)

def update(request):
    if request.method=="POST":
        acha_e_perdido.objects.filter(pk=request.POST['arg']).update(STATUS_HISTORICO="Achado")
    data_f=acha_e_perdido.objects.all()
    context={'data_f':data_f} 
    return render(request, "update.html", context)


def api(request):
    try:
        if request.method=="POST" and request.POST['a']== 'update':
            api_bd.objects.filter(pk=request.POST['arg']).update(like='S')
            data_f=api_bd.objects.all()
            context={'data_f':data_f} 
            return render(request, "api.html", context)
        if request.method=="POST" and request.POST['a']== 'ex':
            api_bd.objects.filter(pk=request.POST['arg']).delete()
            data_f=api.objects.all()
            context={'data_f':data_f} 
            return render(request, "api.html", context)
    except Exception as i:
        pass
    if request.method=="POST":        
        r=request.POST.copy()
        import requests
        import json
        url = "https://catfact.ninja/fact"
        payload={}
        headers = {}
        response = requests.request("GET", url, headers=headers, data=payload)
        r.update({'response': response.text})
        r.update({'fact': json.loads(response.text)['fact']})
        form=form_api(r)
        if form.is_valid():
            form.save() 
    data_f=api_bd.objects.all()
    context={'data_f':data_f} 
    return render(request, "api.html", context)

def error_500(request,exception=''):
    context={}
    return render(request, "error_2.html" ,context)